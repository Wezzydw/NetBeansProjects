import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Score here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Score extends Actor
{
    private int counter;
    private int scorePlayer;
    private int scorePaddle;
    private int level = 1;
    private PingWorld pingWorld;
    
    /**
     * Constructor sets the image to null. 
     */
    public Score()
    {
        setImage((GreenfootImage)null);
    }
    
  
    

    /**
     * Act - do whatever the Score wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        drawText();
    }    
    
    /**
     * Updates scorePlayer with desired input
     */
    public void updateScorePlayer(int points)
    {
        scorePlayer += points;
    }
    
    /**
     * Updates scorePaddle with desired input
     */
    public void updateScorePaddle(int points)
    {
        scorePaddle += points;
    }
    
    /**
     * Updates level in +1 increments
     */
    public void updateLevel()
    {
        level++;
    }

    /**
     * Displays text in form of Game Level and scores.
     */
    public void drawText()
    {
        pingWorld = getWorldOfType(PingWorld.class);
        if (pingWorld != null)
        {
            pingWorld.showText("Game Level " + level, 75, 25);
        }
        pingWorld.showText (scorePlayer + "", 457, 398);
        pingWorld.showText (scorePaddle + "", 38, 310);
    }
}
    
    

